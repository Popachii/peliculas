import { Component, OnInit } from '@angular/core';
import pelis from '../data/movies.json';
// Una forma sencilla de importar datos de un json local, requiere añadir el resolvejsonmodule en el archivo tsconfig del proyecto.

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Directorio de Películas';
  lista_pelis = pelis;
  print_pelis = this.lista_pelis;
  draw_pelis = this.print_pelis;

  init_pag:number=1;
  end_pag:number=this.init_pag+9;


  // La función ngOnInit forma parte del core/scope de Angular e indica que su contenido se ejecutará al momento de inicializar la
  // aplicación, antes de pintar la vista.
  ngOnInit() {
    // Sustituir nulos por Desconocido en el dataset, con el fin de evitar problemas al buscar/ordenar/mostrar valores en pantalla.
    // La función map devuelve una callback de cada elemento de un array, una forma de recorrerlo más eficiente que usando un loop.
    this.print_pelis.map(peli => {
      if(peli.director == null) {
        peli.director = "Desconocido"
      }
      if(peli.cast == null) {
        peli.cast = "Desconocido"
      }
      if(peli.genre == null) {
        peli.genre = "Desconocido"
      }
      if(peli.notes == null) {
        peli.notes = "Desconocido"
      }
    })
    this.draw_pelis = this.print_pelis;
  }
  // Función de búsqueda, unifica todos los buscadores con variables opcionales, ejecutando la búsqueda si la variable se indica.
  // MEJORA: opción RESET, las búsquedas se realizan por defecto sobre la búsqueda anterior, para volver al dataset incial se debe
  // ejecutar el buscador en blanco.
  search(title?: string, year?: string, director?: string, cast?: string, genre?: string, notes?: string) {
    let filter_pelis = new Array();
    
    if(title) {
      this.lista_pelis.map(peli => {
        if(peli.title.toLowerCase().includes(title.toLowerCase())) {
          filter_pelis.push(peli)
        };
      })
    }
    if(year) {
      this.lista_pelis.map(peli => {
        if(peli.year.toString().toLowerCase().includes(year.toLowerCase())) {
          filter_pelis.push(peli)
        };
      })
    }
    if(director) {
      this.lista_pelis.map(peli => {
        if(peli.director.toLowerCase().includes(director.toLowerCase())) {
          filter_pelis.push(peli)
        };
      })
    }
    if(cast) {
      this.lista_pelis.map(peli => {
        if(peli.cast.toLowerCase().includes(cast.toLowerCase())) {
          filter_pelis.push(peli)
        };
      })
    }
    if(genre) {
      this.lista_pelis.map(peli => {
        if(peli.genre.toLowerCase().includes(genre.toLowerCase())) {
          filter_pelis.push(peli)
        };
      })
    }
    if(notes) {
      this.lista_pelis.map(peli => {
        if(peli.notes.toLowerCase().includes(notes.toLowerCase())) {
          filter_pelis.push(peli)
        };
      })
    }
    this.print_pelis = filter_pelis;
    this.draw_pelis = this.print_pelis;
  }

  // Función ordenar, unifica todos los botones de ordenar pasándole un valor referenciando la columna a ordenar y un orden, 
  // ascendente o descendente.
  // MEJORA 1: Orden múltiple, no permite ordenar por varios criterios de ordenación, esto podría realizarse de forma relativamente
  // sencilla trackeando el orden en el que el usuario hace click en los botones ordenar mediante una fla, por ejemplo.
  // MEJORA 2: Normalización de los datos, el orden se muestra de forma algo extraña debido a la ordenación ASCII por defecto, se
  // podrían normalizar los datos/establecer criterios de ordenación específicos para mejorar la experiecia de usuario en este sentido.
  // Ahora mismo la única normalización en el código consiste en la equiparación de mayúsculas y minúsculas.
  sort(value: string, order: string) {
    if(value == "title") {
      if(order == "asc") {
        this.print_pelis.sort((a,b) => (a.title.toLowerCase() > b.title.toLowerCase()) ? 1 : 
        ((a.title.toLowerCase() < b.title.toLowerCase()) ? -1 : 0))
      } else {
        this.print_pelis.sort((a,b) => (a.title.toLowerCase() > b.title.toLowerCase()) ? -1 : 
        ((a.title.toLowerCase() < b.title.toLowerCase()) ? 1 : 0))
      }
    }
    if(value == "year") {
      if(order == "asc") {
        this.print_pelis.sort((a,b) => (a.year > b.year) ? 1 : ((a.year < b.year) ? -1 : 0))
      } else {
        this.print_pelis.sort((a,b) => (a.year > b.year) ? -1 : ((a.year < b.year) ? 1 : 0))
      }
    }
    if(value == "director") {
      if(order == "asc") {
        this.print_pelis.sort((a,b) => (a.director.toLowerCase() > b.director.toLowerCase()) ? 1 : 
        ((a.director.toLowerCase() < b.director.toLowerCase()) ? -1 : 0))
      } else {
        this.print_pelis.sort((a,b) => (a.director.toLowerCase() > b.director.toLowerCase()) ? -1 : 
        ((a.director.toLowerCase() < b.director.toLowerCase()) ? 1 : 0))
      }    }
    if(value == "cast") {
      if(order == "asc") {
        this.print_pelis.sort((a,b) => (a.cast.toLowerCase() > b.cast.toLowerCase()) ? 1 : 
        ((a.cast.toLowerCase() < b.cast.toLowerCase()) ? -1 : 0))
      } else {
        this.print_pelis.sort((a,b) => (a.cast.toLowerCase() > b.cast.toLowerCase()) ? -1 : 
        ((a.cast.toLowerCase() < b.cast.toLowerCase()) ? 1 : 0))
      }    }
    if(value == "genre") {
      if(order == "asc") {
        this.print_pelis.sort((a,b) => (a.genre.toLowerCase() > b.genre.toLowerCase()) ? 1 : 
        ((a.genre.toLowerCase() < b.genre.toLowerCase()) ? -1 : 0))
      } else {
        this.print_pelis.sort((a,b) => (a.genre.toLowerCase() > b.genre.toLowerCase()) ? -1 : 
        ((a.genre.toLowerCase() < b.genre.toLowerCase()) ? 1 : 0))
      }    }
    if(value == "notes") {
      if(order == "asc") {
        this.print_pelis.sort((a,b) => (a.notes.toLowerCase() > b.notes.toLowerCase()) ? 1 : 
        ((a.genre.toLowerCase() < b.genre.toLowerCase()) ? -1 : 0))
      } else {
        this.print_pelis.sort((a,b) => (a.notes.toLowerCase() > b.notes.toLowerCase()) ? -1 : 
        ((a.genre < b.genre) ? 1 : 0))
      }    
    }
    this.draw_pelis = this.print_pelis;
  }

  // Función paginado, permite avanzar más allá de las 10 primeras filas al consultar la tabla, y viceversa. Se utiliza como parámetro
  // una flag, 0 ó 1, que indica si se está paginando hacia filas superiores o inferiores.
  // MEJORA: en un caso real, con la tabla interactuando con otros objetos, las funciónes buscar, ordenar y paginado deben establecerse
  // como un conjunto, cada una de las tres funciones debe saber el "estado actual" de las otras dos antes de proceder a actualizar su
  // propio estado para evitar riesgos de pérdida/alteración de registros.
  pag(n:number) {
    if(n == 0) {
      if(this.init_pag < 11) {
        this.init_pag = 1;
        this.end_pag = this.init_pag + 9;
      } else {
        this.init_pag = this.init_pag - 10;
        this.end_pag = this.init_pag + 9;
      }
    }
    if(n == 1) {
      if(this.end_pag > this.print_pelis.length - 10) {
        this.end_pag = this.print_pelis.length;
        this.init_pag = this.end_pag - 9;
      } else {
        this.init_pag = this.init_pag + 10;
        this.end_pag = this.init_pag + 9;
      }
    }
    this.draw_pelis = this.print_pelis;
  }
}

